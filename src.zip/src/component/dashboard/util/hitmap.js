// === Hitmap: id <-> RGB 매핑 & 픽셀 피킹 ===

export function idToRGB(id) {
    // 기존 FNV-1a 기반 해시 (충분히 낮은 충돌률)
    let h = 2166136261 >>> 0;
    const s = String(id);
    for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 16777619);
    }
    const r = (h & 0xff0000) >>> 16;
    const g = (h & 0x00ff00) >>> 8;
    const b = (h & 0x0000ff) >>> 0;
    return { r, g, b };
}

export function rgbToKey(r, g, b) {
    return (r << 16) | (g << 8) | b;
}

export function rgbToCss({ r, g, b }) {
    return `rgb(${r},${g},${b})`;
}

export function ensureBBox(s) {
    if (s?.bbox) {
        const { x, y, w, h } = s.bbox;
        return {
            x: Math.min(x, x + w),
            y: Math.min(y, y + h),
            w: Math.abs(w),
            h: Math.abs(h),
        };
    }
    const x = s.x ?? s.x0 ?? 0;
    const y = s.y ?? s.y0 ?? 0;
    const w = s.w ?? (s.x1 != null ? s.x1 - x : 0);
    const h = s.h ?? (s.y1 != null ? s.y1 - y : 0);
    return {
        x: Math.min(x, x + w),
        y: Math.min(y, y + h),
        w: Math.abs(w),
        h: Math.abs(h),
    };
}

// --- 내부 유틸: 도형 path ---
function pathEllipse(ctx, bb) {
    const cx = bb.x + bb.w / 2,
        cy = bb.y + bb.h / 2;
    const rx = bb.w / 2,
        ry = bb.h / 2;
    ctx.beginPath();
    ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
}
function pathPolygon(ctx, pts) {
    if (!pts || pts.length < 4) return false;
    ctx.beginPath();
    ctx.moveTo(pts[0], pts[1]);
    for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
    ctx.closePath();
    return true;
}
function starPointsFromBBox(s) {
    const b = ensureBBox(s);
    const spikes = Math.max(3, Number(s.spikes ?? s.style?.spikes ?? 5));
    const innerRatio = Number.isFinite(s.innerRatio ?? s.style?.innerRatio)
        ? (s.innerRatio ?? s.style?.innerRatio)
        : 0.5;
    const cx = b.x + b.w / 2,
        cy = b.y + b.h / 2;
    const rOuter = Math.min(b.w, b.h) / 2;
    const rInner = rOuter * innerRatio;
    const pts = [];
    const N = spikes * 2;
    const rot = -Math.PI / 2;
    for (let i = 0; i < N; i++) {
        const r = i % 2 === 0 ? rOuter : rInner;
        const a = rot + (i * Math.PI) / spikes;
        pts.push(cx + r * Math.cos(a), cy + r * Math.sin(a));
    }
    return pts;
}

// 추가: 주어진 반경 안에서 가장 많이 나온 색을 선택
export function pickAtRadius(ctx, cssX, cssY, radius = 2) {
    if (!ctx) return null;
    const tf = ctx.getTransform ? ctx.getTransform() : { a: 1 };
    const dpr = (tf && typeof tf.a === 'number' ? tf.a : 1) || ctx.__dpr || 1;

    const r = Math.max(1, Math.round(radius * dpr));
    const ix = Math.floor(cssX * dpr);
    const iy = Math.floor(cssY * dpr);

    const sx = Math.max(0, ix - r),
        sy = Math.max(0, iy - r);
    const ex = Math.min(ctx.canvas.width, ix + r + 1);
    const ey = Math.min(ctx.canvas.height, iy + r + 1);
    const w = ex - sx,
        h = ey - sy;
    if (w <= 0 || h <= 0) return null;

    const data = ctx.getImageData(sx, sy, w, h).data;
    const cnt = new Map();
    for (let y = -r; y <= r; y++) {
        for (let x = -r; x <= r; x++) {
            if (x * x + y * y > r * r) continue; // 원형 영역만
            const px = ix + x - sx,
                py = iy + y - sy;
            if (px < 0 || py < 0 || px >= w || py >= h) continue;
            const i = (py * w + px) * 4;
            const key = rgbToKey(data[i], data[i + 1], data[i + 2]);
            if (key === 0) continue;
            cnt.set(key, (cnt.get(key) || 0) + 1);
        }
    }
    if (!cnt.size) return null;
    let bestKey = null,
        bestCnt = -1;
    for (const [k, c] of cnt) {
        if (c > bestCnt) {
            bestCnt = c;
            bestKey = k;
        }
    }
    return bestKey;
}

// 추가: 먼저 3×3, 실패 시 반경 확대로 재도전
export function pickAtSmart(ctx, cssX, cssY, radius = 2) {
    const k1 = pickAt(ctx, cssX, cssY);
    if (k1) return k1;
    return pickAtRadius(ctx, cssX, cssY, radius);
}

// 히트맵 렌더 (도형마다 고유색, stroke/lineWidth 반영)
export function drawPickBuffer(ctx, shapes) {
    if (!ctx) return;
    const { width, height } = ctx.canvas;

    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.globalCompositeOperation = 'source-over';
    ctx.clearRect(0, 0, width, height);

    for (const s of shapes) {
        const { r, g, b } = idToRGB(s.id);
        const color = `rgb(${r},${g},${b})`;
        ctx.fillStyle = color;
        ctx.strokeStyle = color;

        const bb = ensureBBox(s);
        if (bb.w <= 0 || bb.h <= 0) continue;

        // 선 굵기(관용치 +1)
        const lw = Math.max(1, (s.style?.strokeWidth ?? 1) + 2);
        ctx.lineWidth = lw;
        ctx.lineJoin = s.style?.lineJoin || 'miter';
        ctx.lineCap = s.style?.lineCap || 'butt';

        switch (s.type) {
            case 'rect': {
                // stroke-only 도형도 클릭되도록 채우기 + 스트로크
                ctx.fillRect(bb.x, bb.y, bb.w, bb.h);
                // 굳이 stroke는 필요없지만, 경계정확도를 위해 유지
                ctx.strokeRect(bb.x, bb.y, bb.w, bb.h);
                break;
            }
            case 'ellipse': {
                pathEllipse(ctx, bb);
                // 내부 클릭 허용
                ctx.fill();
                ctx.stroke();
                break;
            }
            case 'line': {
                const x1 = s.x1 ?? s.x ?? 0;
                const y1 = s.y1 ?? s.y ?? 0;
                const x2 = s.x2 ?? s.x1 ?? 0;
                const y2 = s.y2 ?? s.y1 ?? 0;
                ctx.beginPath();
                ctx.moveTo(x1, y1);
                ctx.lineTo(x2, y2);
                ctx.stroke();
                break;
            }
            case 'polygon': {
                const pts = s.data?.points || s.points || [];
                if (pathPolygon(ctx, pts)) {
                    ctx.fill(); // 폴리곤 내부 클릭 허용
                    ctx.stroke();
                }
                break;
            }
            case 'star': {
                const pts =
                    s.points && s.points.length >= 6
                        ? s.points
                        : starPointsFromBBox(s);
                if (pathPolygon(ctx, pts)) {
                    ctx.fill();
                    ctx.stroke();
                }
                break;
            }
            case 'path':
            case 'polyline': {
                const pts = s.data?.points || s.points || [];
                if (pts.length >= 4) {
                    ctx.beginPath();
                    ctx.moveTo(pts[0], pts[1]);
                    for (let i = 2; i < pts.length; i += 2)
                        ctx.lineTo(pts[i], pts[i + 1]);
                    // polyline은 열려 있을 수 있음 → 닫지 않음
                    if (s.type === 'path') ctx.closePath();
                    if (s.style?.fill && s.type === 'path') ctx.fill();
                    ctx.stroke();
                }
                break;
            }
            default: {
                // 폴백: bbox 채우기
                ctx.fillRect(bb.x, bb.y, bb.w, bb.h);
            }
        }
    }
    ctx.restore();
}

// DPR 반영 + 3×3 다수결 샘플로 경계 픽 안정화
export function pickAt(ctx, cssX, cssY) {
    if (!ctx) return null;
    const { width, height } = ctx.canvas;

    const tf = ctx.getTransform ? ctx.getTransform() : { a: 1 };
    const dpr = (tf && typeof tf.a === 'number' ? tf.a : 1) || ctx.__dpr || 1;

    let ix = Math.floor(cssX * dpr);
    let iy = Math.floor(cssY * dpr);
    if (ix < 0 || iy < 0 || ix >= width || iy >= height) return null;

    // 3x3 window (클램프 포함)
    const sx = Math.max(0, ix - 1),
        sy = Math.max(0, iy - 1);
    const ex = Math.min(width, sx + 3),
        ey = Math.min(height, sy + 3);
    const w = ex - sx,
        h = ey - sy;

    const data = ctx.getImageData(sx, sy, w, h).data;

    // 다수결 색상
    const count = new Map();
    for (let i = 0; i < data.length; i += 4) {
        const k = rgbToKey(data[i], data[i + 1], data[i + 2]);
        if (k === 0) continue;
        count.set(k, (count.get(k) || 0) + 1);
    }
    if (!count.size) return null;

    let bestKey = null,
        bestCnt = -1;
    for (const [k, c] of count) {
        if (c > bestCnt) {
            bestCnt = c;
            bestKey = k;
        }
    }
    return bestKey;
}

export function resolveKeyToId(shapes, key) {
    for (const s of shapes) {
        const { r, g, b } = idToRGB(s.id);
        if (rgbToKey(r, g, b) === key) return s.id;
    }
    return null;
}
