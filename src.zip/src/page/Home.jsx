import CanvasContainer from '../component/dashboard/implementation/CanvasContainer';
import { Header } from '../component/header/implementation/Header';

function Home() {
    return (
        <main>
            <Header />
            <CanvasContainer />
        </main>
    );
}

export default Home;
