import { DPR as getDPR } from './dpr';

function setupCanvas(canvas, cssW, cssH, opts = {}) {
    if (!canvas) return { ctx: null, dpr: 1 };
    const { dpr: overrideDpr, alpha = true, desynchronized = true } = opts;

    const dpr = Math.max(0.5, Number(overrideDpr) || getDPR());

    canvas.width = Math.round(cssW * dpr);
    canvas.height = Math.round(cssH * dpr);
    canvas.style.width = cssW + 'px';
    canvas.style.height = cssH + 'px';

    const ctx = canvas.getContext('2d', { alpha, desynchronized });
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return { ctx, dpr };
}

export { setupCanvas };
