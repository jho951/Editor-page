import { useDispatch, useSelector } from 'react-redux';
import { Icon } from '@/shared/component/icon/Icon';
import { toolbarActions } from '@/lib/redux/slice/toolbar.slice';

/**
 * 도형 섹션의 메인 아이콘을 "현재 툴"에 맞게 동적 렌더링.
 * - tool === 'select' 이면 마우스 커서 아이콘
 * - 나머지 도형이면 그 도형 아이콘
 * 아이콘 클릭 시 'select'로 전환되도록 함.
 */
export default function ShapeSectionIcon({ size = 30 }) {
    const dispatch = useDispatch();
    const tool = useSelector((s) => s.toolbar.tool); // :contentReference[oaicite:2]{index=2}

    const iconName = getShapeIconName(tool);
    const handleClick = () => dispatch(toolbarActions.setTool('select')); // :contentReference[oaicite:3]{index=3}

    return (
        <button
            type="button"
            aria-label="Select tool"
            onClick={handleClick}
            style={{
                appearance: 'none',
                background: 'transparent',
                border: 0,
                padding: 0,
                lineHeight: 0,
                cursor: 'pointer',
            }}
            title="선택 (클릭 시 Select)"
        >
            <Icon name={iconName} size={size} />
        </button>
    );
}

/** 현재 툴에 따라 도형 섹션 아이콘 매핑 */
function getShapeIconName(tool) {
    // 마우스 커서(Select)
    if (tool === 'select') return 'select';

    // 도형군 매핑 (Icon 컴포넌트에서 이미 제공 중인 이름을 사용)
    const map = {
        rect: 'rect',
        ellipse: 'ellipse',
        line: 'line',
        star: 'star',
        polygon: 'polygon',
        path: 'freeDraw',
        text: 'text',
    };
    return map[tool] || 'shape'; // 혹시 모를 기본값
}
