import React, { useRef, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { setSize as setCanvasSize } from '../../../lib/redux/slice/canvasSlice';
import { setupCanvas, renderVector, drawPickBuffer } from '../util';
import { useMarqueeDraw } from '../hook/useMarqueeDraw';
import { useSelectionInteraction } from '../hook/useSelectionInteraction';
import styles from '../style/CanvasContainer.module.css';

function CanvasContainer() {
    const dispatch = useDispatch();

    const hitRef = useRef(null);
    const stageRef = useRef(null);
    const vectorRef = useRef(null);
    const overlayRef = useRef(null);

    const vectorCtxRef = useRef(null);
    const overlayCtxRef = useRef(null);

    const rafRef = useRef(null);
    const lastSizeRef = useRef({ w: 0, h: 0 });

    const initW = useSelector((s) => s.canvas?.width) || 1200;
    const initH = useSelector((s) => s.canvas?.height) || 800;

    const shapes = useSelector((s) => s.shape?.list || []);
    const tool = useSelector((s) => s.tool?.tool);
    const draft = useSelector((s) => s.tool?.draft);

    useEffect(() => {
        if (!stageRef.current) return;

        const scheduleLayout = () => {
            if (rafRef.current) cancelAnimationFrame(rafRef.current);
            rafRef.current = requestAnimationFrame(layout);
        };

        const ro = new ResizeObserver(scheduleLayout);
        ro.observe(stageRef.current);

        let last = window.devicePixelRatio || 1;
        let mql = window.matchMedia(`(resolution: ${last}dppx)`);
        const onDpr = () => {
            const cur = window.devicePixelRatio || 1;
            if (cur === last) return;
            last = cur;
            scheduleLayout();
            try {
                mql.removeEventListener('change', onDpr);
            } catch {
                mql.removeListener(onDpr);
            }
            mql = window.matchMedia(`(resolution: ${last}dppx)`);
            try {
                mql.addEventListener('change', onDpr);
            } catch {
                mql.addListener(onDpr);
            }
        };
        try {
            mql.addEventListener('change', onDpr);
        } catch {
            mql.addListener(onDpr);
        }

        layout(); // 최초 1회

        return () => {
            ro.disconnect();
            try {
                mql.removeEventListener('change', onDpr);
            } catch {
                mql.removeListener(onDpr);
            }
            if (rafRef.current) cancelAnimationFrame(rafRef.current);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    function layout() {
        const stage = stageRef.current;
        if (!stage) return;

        const rect = stage.getBoundingClientRect();
        const cssW = Math.max(1, Math.floor(rect.width));
        const cssH = Math.max(1, Math.floor(rect.height));

        const { w: pw, h: ph } = lastSizeRef.current;
        const changed = pw !== cssW || ph !== cssH;
        if (changed) lastSizeRef.current = { w: cssW, h: cssH };

        const base =
            (typeof window !== 'undefined' && window.devicePixelRatio) || 1;
        const DPR = { vector: Math.min(base, 2.5), hitmap: 1, overlay: 1 };

        // 1) 캔버스 백킹 스토어 준비
        const v = setupCanvas(vectorRef.current, cssW, cssH, {
            dpr: DPR.vector,
            alpha: true,
        });
        const h = setupCanvas(hitRef.current, cssW, cssH, {
            dpr: DPR.hitmap,
            alpha: false,
        });
        const o = setupCanvas(overlayRef.current, cssW, cssH, {
            dpr: DPR.overlay,
            alpha: true,
        });

        // 2) 컨텍스트 보관
        vectorCtxRef.current = v?.ctx || vectorRef.current?.getContext('2d');
        const hitCtx = h?.ctx || hitRef.current?.getContext('2d');
        overlayCtxRef.current = o?.ctx || overlayRef.current?.getContext('2d');

        // 3) 히트맵 DPR 힌트 + 렌더
        if (hitCtx) {
            try {
                hitCtx.__dpr = DPR.hitmap;
            } catch {
                console.warn('에러');
            }
            drawPickBuffer(hitCtx, shapes);
        }

        // 4) 리덕스 사이즈 업데이트
        if (changed) dispatch(setCanvasSize({ width: cssW, height: cssH }));

        // 5) 벡터 다시 그리기
        if (vectorCtxRef.current)
            renderVector(vectorCtxRef.current, shapes, cssW, cssH);
    }

    // 드래그-생성(마퀴)
    useMarqueeDraw({
        overlayRef,
        stageRef,
        getOverlayCtx: () => overlayCtxRef.current,
        getCanvasCssSize: () => {
            const r = stageRef.current?.getBoundingClientRect() || {
                width: 0,
                height: 0,
            };
            return { w: Math.floor(r.width), h: Math.floor(r.height) };
        },
        getTool: () => tool,
        getDraft: () => draft,
        dispatch,
        autoSelect: true,
        constrainShift: true,
        autoReturnSelect: false,
    });

    // shapes 변경 시 재렌더
    useEffect(() => {
        if (!vectorCtxRef.current) layout();
        const r = stageRef.current?.getBoundingClientRect();
        if (!r) return;
        const cssW = Math.floor(r.width),
            cssH = Math.floor(r.height);

        if (vectorCtxRef.current)
            renderVector(vectorCtxRef.current, shapes, cssW, cssH);

        const hitCtx = hitRef.current?.getContext('2d');
        if (hitCtx) drawPickBuffer(hitCtx, shapes);
    }, [shapes]);

    // 선택/이동/리사이즈/삭제
    useSelectionInteraction({
        stageRef,
        overlayRef,
        hitRef,
        getOverlayCtx: () => overlayCtxRef.current,
        getCanvasCssSize: () => {
            const r = stageRef.current?.getBoundingClientRect() || {
                width: 0,
                height: 0,
            };
            return { w: Math.floor(r.width), h: Math.floor(r.height) };
        },
        dispatch,
    });

    return (
        <section className={styles.canvasWrapper}>
            <div
                ref={stageRef}
                className={styles.stage}
                style={{ '--stage-w': `${initW}px`, '--stage-h': `${initH}px` }}
            >
                <canvas
                    ref={vectorRef}
                    className={`${styles.canvasLayer} ${styles.vector}`}
                    data-layer="vector"
                />
                <canvas
                    ref={hitRef}
                    className={`${styles.canvasLayer} ${styles.hitmap}`}
                    data-layer="hitmap"
                />
                <canvas
                    ref={overlayRef}
                    className={`${styles.canvasLayer} ${styles.overlay}`}
                    data-layer="overlay"
                />
            </div>
        </section>
    );
}

export default CanvasContainer;
