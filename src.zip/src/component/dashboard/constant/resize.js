const CANVAS_RESIZE = {
    COLOR: [250, 0, 250],

    KNOB: 12,

    HIT_PAD: 8,

    MIN_W: 100,
    MIN_H: 100,
    MAX_W: 8192,
    MAX_H: 8192,

    PREVIEW: {
        DASH: [6, 4],
        LINE_WIDTH: 1,
        COLOR: '#4c8bf5',
        BADGE_BG: 'rgba(17,24,39,.86)',
        BADGE_FG: '#fff',
        BADGE_PAD: 6,
        BADGE_RADIUS: 8,
        FONT: '12px system-ui, -apple-system, Segoe UI, Roboto, sans-serif',
    },
};
export { CANVAS_RESIZE };
