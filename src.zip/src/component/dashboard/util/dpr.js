const DPR = () =>
    typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1;

function observeDpr(onChange) {
    if (typeof window === 'undefined') return () => {};
    let last = window.devicePixelRatio || 1;
    let mql = window.matchMedia(`(resolution: ${last}dppx)`);

    const handler = () => {
        const cur = window.devicePixelRatio || 1;
        if (cur === last) return;
        last = cur;
        onChange?.(cur);

        // 다음 변화를 위해 media query를 재구독
        try {
            mql.removeEventListener('change', handler);
        } catch {
            mql.removeListener(handler);
        }
        mql = window.matchMedia(`(resolution: ${last}dppx)`);
        try {
            mql.addEventListener('change', handler);
        } catch {
            mql.addListener(handler);
        }
    };

    // 구독
    try {
        mql.addEventListener('change', handler);
    } catch {
        mql.addListener(handler);
    }
    window.addEventListener('resize', handler);
    const vv = window.visualViewport;
    vv && vv.addEventListener('resize', handler);

    // 정리
    return () => {
        try {
            mql.removeEventListener('change', handler);
        } catch {
            mql.removeListener(handler);
        }
        window.removeEventListener('resize', handler);
        vv && vv.removeEventListener('resize', handler);
    };
}

export { DPR, observeDpr };
