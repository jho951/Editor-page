import { Icon } from '@/shared/component/icon/Icon';
import { HEADER_ELEMENTS } from './item';

const DROPDOWN_SECTION = [
    {
        key: 'file',
        label: '파일',
        icon: <Icon name="open" size={HEADER_ELEMENTS.ITEM_SIZE + 4} />,
        items: HEADER_ELEMENTS.FILE_ITEM,
    },
    HEADER_ELEMENTS.DEFAULT_ITEM[0],
    {
        key: 'shape',
        label: '도형',

        icon: <Icon name="shape" size={HEADER_ELEMENTS.ITEM_SIZE + 4} />,
        items: HEADER_ELEMENTS.SHAPE_ITEM,
    },
    {
        key: 'transform',
        label: '변형',

        icon: <Icon name="transform" size={HEADER_ELEMENTS.ITEM_SIZE + 4} />,
        items: HEADER_ELEMENTS.TRANSFORM_ITEM,
    },
    HEADER_ELEMENTS.HISTORY_ITEM[0],
    HEADER_ELEMENTS.HISTORY_ITEM[1],
];

export { DROPDOWN_SECTION };

// src/features/header/config/sections.js
import { Icon } from '@/shared/component/icon/Icon';
import ShapeSectionIcon from '../components/ShapeSectionIcon';
import { HEADER_ELEMENTS } from './item';

export function buildDropdownSections() {
    return [
        {
            key: 'file',
            label: '파일',
            icon: <Icon name="open" size={HEADER_ELEMENTS.ITEM_SIZE + 4} />,
            items: HEADER_ELEMENTS.FILE_ITEM,
        },

        // ✅ 더 이상 단독 select 아이템은 상단에 두지 않음
        // HEADER_ELEMENTS.DEFAULT_ITEM[0],  // ← 제거

        {
            key: 'shape',
            label: '도형',
            // ✅ 도형만 아이콘 동적 (현재 툴이 select면 마우스 커서 아이콘)
            icon: <ShapeSectionIcon size={HEADER_ELEMENTS.ITEM_SIZE + 4} />,
            items: HEADER_ELEMENTS.SHAPE_ITEM, // 기존 도형 리스트 그대로
        },
        {
            key: 'transform',
            label: '변형',
            icon: (
                <Icon name="transform" size={HEADER_ELEMENTS.ITEM_SIZE + 4} />
            ),
            items: HEADER_ELEMENTS.TRANSFORM_ITEM,
        },
        // 히스토리(undo/redo)는 그대로
        ...HEADER_ELEMENTS.HISTORY_ITEM,
    ];
}
