import { useCallback, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { IconBtn } from '@/shared/component/button/IconBtn';
import { DropDown } from '@/shared/component/context/DropDown';
import { toArray } from '@/shared/util/to-array';
import styles from './Lnb.module.css';

import { useHeaderAction } from '../hook/useHeaderAction';
import { toolbarActions } from '@/feature/toolbar/state/toolbar.slice';

import {
    selectSectionActive,
    selectSidebarOpen,
} from '@/feature/toolbar/state/toolbar.selector';
import { setSidebarOpen } from '@/feature/toolbar/state/toolbar.slice';

import { HEADER_ELEMENTS } from '@/feature/toolbar/constant/item';
import { DROPDOWN_SECTION } from '@/feature/toolbar/constant/section';

function Lnb() {
    const dispatch = useDispatch();
    const { onCommand } = useHeaderAction();

    const openKey = useSelector(selectSidebarOpen);
    const sectionActive = useSelector(selectSectionActive);

    const toggle = useCallback(
        (sec, hasItems) => {
            const key = sec?.key;
            const has = Array.isArray(hasItems)
                ? hasItems.length > 0
                : !!hasItems;
            if (key === 'shape') {
                dispatch(toolbarActions.setTool('select')); // toolbarSlice.setTool이 sectionActive도 함께 갱신:contentReference[oaicite:2]{index=2}
            }
            // 아이템이 없으면 즉시 커맨드 실행(파일 같은 단일 액션 섹션에 대비)
            if (!has) {
                onCommand(key);
                return;
                dispatch(setSidebarOpen(openKey === key ? null : key));
            }
        },
        [dispatch, openKey, onCommand]
    );

    const getSectionIcon = useCallback(
        (sec) => {
            if (sec.key === 'shape') {
                const activeKey = sectionActive?.shape;
                if (activeKey) {
                    const candidates = [
                        ...HEADER_ELEMENTS.DEFAULT_ITEM, // ← 여기에 select 아이콘이 있으니 목록엔 안 보여도 아이콘 추출 가능
                        ...HEADER_ELEMENTS.SHAPE_ITEM,
                    ];
                    const it = candidates.find((x) => x.key === activeKey);
                    if (it?.icon) return it.icon;
                }
                return sec.icon; // fallback
            }
            return sec.icon;
        },
        [sectionActive]
    );

    const isActiveRow = useCallback(
        (sec) => {
            if (sec.key === 'shape') {
                return openKey === 'shape' || Boolean(sectionActive?.shape);
            }
            if (sec.key === 'file') return openKey === 'file';
            return false;
        },
        [openKey, sectionActive]
    );

    const onSelectItem = useCallback(
        (itemKey) => {
            onCommand(itemKey);
            dispatch(setSidebarOpen(null));
        },
        [onCommand, dispatch]
    );

    const sections = useMemo(() => DROPDOWN_SECTION, []);

    return (
        <nav className={styles.wrap} aria-label="Toolbar">
            {sections.map((sec) => (
                <div className={styles.row} key={sec.key}>
                    <IconBtn
                        className={`${styles.btn} ${isActiveRow(sec) ? styles.btnActive : ''}`}
                        title={sec.label}
                        icon={getSectionIcon(sec)}
                        onClick={() => toggle(sec, toArray(sec.items))}
                    />

                    {openKey === sec.key && toArray(sec.items).length > 0 && (
                        <DropDown
                            items={toArray(sec.items)}
                            onSelect={onSelectItem}
                            active={sectionActive?.[sec.key]}
                            open
                            side="right"
                        />
                    )}
                </div>
            ))}
        </nav>
    );
}

export { Lnb };
