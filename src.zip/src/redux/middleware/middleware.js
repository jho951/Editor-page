/**
 * @file src/redux/middleware/historyChannels.js
 * @description
 * ✅ 비트맵 채널 완전 제거, 벡터(=shape 상태)만 히스토리 관리
 *
 * - 벡터 변경 액션(화이트리스트) 발생 시:
 *   -> next(action) 전의 state.shape 스냅샷을 past 스택에 push
 *   -> future 정리는 history 리듀서에 위임
 * - 벡터 undo/redo:
 *   -> history/undoVector, history/redoVector 인터셉트
 *   -> history 리듀서에 popPastVector/popFutureVector 요청
 *   -> pop 결과 스냅샷(applied)을 shape/replaceAll로 복원
 *
 * 필요 조건:
 * - historySlice: pushPastVector / pushFutureVector / popPastVector / popFutureVector / (옵션) clearVectorHistory
 * - shapeSlice: replaceAll(payload = 전체 shape 서브트리 스냅샷)
 */

const VECTOR_MUTATIONS = [
    'shape/add',
    'shape/update',
    'shape/remove',
    'shape/transform',
    'shape/reorder',
    'shape/clear',
];

// historySlice 액션 타입
const PUSH_PAST_VECTOR = 'history/pushPastVector';
const PUSH_FUTURE_VECTOR = 'history/pushFutureVector';
const POP_PAST_VECTOR = 'history/popPastVector';
const POP_FUTURE_VECTOR = 'history/popFutureVector';

// 단축키/버튼에서 디스패치하는 트리거
const UNDO_VECTOR = 'history/undoVector';
const REDO_VECTOR = 'history/redoVector';

// shape 전체 상태 교체 (shapeSlice에 구현되어 있어야 함)
const SHAPE_REPLACE_ALL = 'shape/replaceAll';

/* ------------------------------------------------------
 * 벡터 전용 채널 미들웨어
 * ----------------------------------------------------*/
export function vectorChannelMiddleware({ getState, dispatch }) {
    return (next) => (action) => {
        // 1) undo/redo 트리거 우선 처리
        if (action.type === UNDO_VECTOR) {
            // 현재 상태를 future 로 보관하고, past 에서 하나 꺼내 복원
            const currentShape = getState()?.shape;
            const result = next({ type: POP_PAST_VECTOR });
            const snap = getState()?.history?.vector?.applied;
            if (snap) {
                // 현재 상태는 future 로 밀어둔다
                const clonedCurrent = JSON.parse(JSON.stringify(currentShape));
                dispatch({
                    type: PUSH_FUTURE_VECTOR,
                    payload: { snapshot: clonedCurrent },
                });
                dispatch({ type: SHAPE_REPLACE_ALL, payload: snap });
            }
            return result;
        }

        if (action.type === REDO_VECTOR) {
            // 현재 상태를 past 로 보관하고, future 에서 하나 꺼내 복원
            const currentShape = getState()?.shape;
            const result = next({ type: POP_FUTURE_VECTOR });
            const snap = getState()?.history?.vector?.applied;
            if (snap) {
                const clonedCurrent = JSON.parse(JSON.stringify(currentShape));
                dispatch({
                    type: PUSH_PAST_VECTOR,
                    payload: { snapshot: clonedCurrent },
                });
                dispatch({ type: SHAPE_REPLACE_ALL, payload: snap });
            }
            return result;
        }

        // 2) 일반 액션은 먼저 이전 상태를 잡아두고, next(action) 적용
        const beforeShape = getState()?.shape;
        const result = next(action);

        // 3) 벡터 변경 액션이면, "변경 전" 스냅샷을 past 에 저장
        if (VECTOR_MUTATIONS.includes(action.type)) {
            // 상태가 POJO라는 가정 하에 JSON 딥클론
            const clonedBefore = JSON.parse(JSON.stringify(beforeShape));
            dispatch({
                type: PUSH_PAST_VECTOR,
                payload: { snapshot: clonedBefore },
            });
            // future 정리는 history 리듀서가 책임지도록 설계(일반적으로 past push 시 future clear)
        }

        return result;
    };
}

/* ------------------------------------------------------
 * 번들러: store.ts/js 에서 사용
 *   const middleware = buildAppMiddleware(getDefaultMiddleware);
 *   export const store = configureStore({ reducer, middleware });
 * ----------------------------------------------------*/
export default function buildAppMiddleware(getDefaultMiddleware) {
    const base = getDefaultMiddleware({
        serializableCheck: {
            ignoredActions: [
                PUSH_PAST_VECTOR,
                PUSH_FUTURE_VECTOR,
                POP_PAST_VECTOR,
                POP_FUTURE_VECTOR,
                UNDO_VECTOR,
                REDO_VECTOR,
                SHAPE_REPLACE_ALL,
            ],
            ignoredPaths: [
                'history.vector.past',
                'history.vector.future',
                'history.vector.applied',
                'shape',
            ],
        },
        immutableCheck: false,
    });

    // ✅ 비트맵 채널 미들웨어 제거
    return base.concat(vectorChannelMiddleware);
}
