function ensureBBox(s) {
    if (s?.bbox) {
        const { x, y, w, h } = s.bbox;
        const nx = Math.min(x, x + w);
        const ny = Math.min(y, y + h);
        return { x: nx, y: ny, w: Math.abs(w), h: Math.abs(h) };
    }
    const x = s.x ?? s.x0 ?? 0;
    const y = s.y ?? s.y0 ?? 0;
    const w = s.w ?? (s.x1 != null ? s.x1 - x : 0);
    const h = s.h ?? (s.y1 != null ? s.y1 - y : 0);
    const nx = Math.min(x, x + w);
    const ny = Math.min(y, y + h);
    return { x: nx, y: ny, w: Math.abs(w), h: Math.abs(h) };
}

function applyStyle(ctx, style = {}) {
    const { stroke = '#111', fill = null, strokeWidth = 1 } = style || {};
    ctx.lineWidth = strokeWidth ?? 1;
    ctx.strokeStyle = stroke ?? '#111';
    if (fill === '' || fill == null) ctx.fillStyle = 'rgba(0,0,0,0)';
    else ctx.fillStyle = fill;
}

function drawRect(ctx, s) {
    const b = ensureBBox(s);
    if (b.w <= 0 || b.h <= 0) return;
    applyStyle(ctx, s.style);
    if (s.style?.fill) ctx.fillRect(b.x, b.y, b.w, b.h);
    ctx.strokeRect(b.x, b.y, b.w, b.h);
}

function drawEllipse(ctx, s) {
    const b = ensureBBox(s);
    if (b.w <= 0 || b.h <= 0) return;
    const cx = b.x + b.w / 2,
        cy = b.y + b.h / 2;
    const rx = b.w / 2,
        ry = b.h / 2;
    applyStyle(ctx, s.style);
    ctx.beginPath();
    ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
    if (s.style?.fill) ctx.fill();
    ctx.stroke();
}

function drawLine(ctx, s) {
    const x1 = s.x1 ?? s.x ?? 0;
    const y1 = s.y1 ?? s.y ?? 0;
    const x2 = s.x2 ?? s.x1 ?? 0;
    const y2 = s.y2 ?? s.y1 ?? 0;
    applyStyle(ctx, s.style);
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
}

function pathFromPoints(ctx, pts) {
    if (!pts || pts.length < 4) return;
    ctx.beginPath();
    ctx.moveTo(pts[0], pts[1]);
    for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
    ctx.closePath();
}

function drawPolygon(ctx, s) {
    const pts = s.points || s.data?.points;
    if (!pts?.length) return;
    applyStyle(ctx, s.style);
    pathFromPoints(ctx, pts);
    if (s.style?.fill) ctx.fill();
    ctx.stroke();
}

function starPointsFromBBox(s) {
    const b = ensureBBox(s);
    const spikes = Math.max(3, Number(s.spikes ?? s.style?.spikes ?? 5));
    const innerRatio = Number.isFinite(s.innerRatio ?? s.style?.innerRatio)
        ? (s.innerRatio ?? s.style?.innerRatio)
        : 0.5;
    const cx = b.x + b.w / 2,
        cy = b.y + b.h / 2;
    const rOuter = Math.min(b.w, b.h) / 2;
    const rInner = rOuter * innerRatio;
    const pts = [];
    const N = spikes * 2;
    const rot = -Math.PI / 2;
    for (let i = 0; i < N; i++) {
        const r = i % 2 === 0 ? rOuter : rInner;
        const a = rot + (i * Math.PI) / spikes;
        pts.push(cx + r * Math.cos(a), cy + r * Math.sin(a));
    }
    return pts;
}

function drawStar(ctx, s) {
    const pts =
        s.points && s.points.length >= 6 ? s.points : starPointsFromBBox(s);
    applyStyle(ctx, s.style);
    pathFromPoints(ctx, pts);
    if (s.style?.fill) ctx.fill();
    ctx.stroke();
}

export function renderVector(ctx, shapes = [], cssW = 0, cssH = 0) {
    if (!ctx) return;
    if (cssW && cssH) ctx.clearRect(0, 0, cssW, cssH);

    for (const s of shapes) {
        switch (s.type) {
            case 'rect':
                drawRect(ctx, s);
                break;
            case 'ellipse':
                drawEllipse(ctx, s);
                break;
            case 'line':
                drawLine(ctx, s);
                break;
            case 'polygon':
                drawPolygon(ctx, s);
                break;
            case 'star':
                drawStar(ctx, s);
                break;
            default:
                if (s.points) drawPolygon(ctx, s);
                else drawRect(ctx, s);
        }
    }
}
