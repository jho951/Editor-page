import { CANVAS_RESIZE as CR } from '../constant/resize';

function drawCanvasResizeKnob(ctx, width, height) {
    const k = CR.KNOB;
    const x = width - k - 0.5;
    const y = height - k - 0.5;
    ctx.save();
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(0,0,0,.28)';
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.rect(x, y, k, k);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.strokeStyle = 'rgba(0,0,0,.32)';
    ctx.moveTo(width - 4.5, height - k + 2.5);
    ctx.lineTo(width - k + 2.5, height - 4.5);
    ctx.moveTo(width - 7.5, height - k + 5.5);
    ctx.lineTo(width - k + 5.5, height - 7.5);
    ctx.stroke();
    ctx.restore();
}

function drawCanvasResizeHitbox(hctx, width, height) {
    const k = CR.KNOB + CR.HIT_PAD;
    const x = width - k;
    const y = height - k;
    const [r, g, b] = CR.COLOR;
    hctx.save();
    hctx.imageSmoothingEnabled = false;
    hctx.fillStyle = `rgb(${r},${g},${b})`;
    hctx.fillRect(x, y, k, k);
    hctx.restore();
}

function observeElementSize(el, onSize) {
    if (!el || typeof ResizeObserver === 'undefined') return () => {};
    const ro = new ResizeObserver(() => onSize?.());
    ro.observe(el);
    return () => ro.disconnect();
}

export { drawCanvasResizeKnob, drawCanvasResizeHitbox, observeElementSize };
