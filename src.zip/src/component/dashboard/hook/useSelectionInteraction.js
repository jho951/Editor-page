import { useEffect, useRef } from 'react';
import { useSelector, useStore } from 'react-redux';
import {
    drawPickBuffer,
    pickAtSmart,
    resolveKeyToId,
    ensureBBox,
} from '../util/hitmap';
import {
    clearSelectionOverlay as clearOverlay,
    drawSelectionOverlay,
} from '../util/selectionOverlay';
import { setSelection } from '../../../lib/redux/slice/selectionSlice';
import {
    translateShapes,
    scaleShapes,
    removeShapes,
} from '../../../lib/redux/slice/shapeSlice';

function hitHandle(bb, x, y, pad = 8) {
    if (!bb) return null;
    const { x: bx, y: by, w, h } = bb;
    const cx = bx + w / 2,
        cy = by + h / 2;
    const handles = [
        { k: 'nw', px: bx, py: by },
        { k: 'n', px: cx, py: by },
        { k: 'ne', px: bx + w, py: by },
        { k: 'w', px: bx, py: cy },
        { k: 'e', px: bx + w, py: cy },
        { k: 'sw', px: bx, py: by + h },
        { k: 's', px: cx, py: by + h },
        { k: 'se', px: bx + w, py: by + h },
    ];
    for (const hnd of handles) {
        if (Math.abs(x - hnd.px) <= pad && Math.abs(y - hnd.py) <= pad)
            return hnd.k;
    }
    return null;
}
const cursorForHandle = (h) =>
    ({
        nw: 'nwse-resize',
        se: 'nwse-resize',
        ne: 'nesw-resize',
        sw: 'nesw-resize',
        n: 'ns-resize',
        s: 'ns-resize',
        w: 'ew-resize',
        e: 'ew-resize',
    })[h] || 'default';

export function useSelectionInteraction({
    stageRef,
    overlayRef,
    hitRef,
    getOverlayCtx,
    getCanvasCssSize,
    dispatch,
}) {
    const store = useStore();
    const shapes = useSelector((s) => s.shape?.list || []);
    const selectedId = useSelector((s) => s.selection?.id || null);

    console.log(shapes);
    console.log(selectedId);

    const dragRef = useRef(null);
    const lastShapeCountRef = useRef(0);

    useEffect(() => {
        const ctx = hitRef.current?.getContext('2d');
        drawPickBuffer(ctx, shapes);
        lastShapeCountRef.current = shapes.length;
    }, [shapes, hitRef]);

    // selection 변경 → 선택 윤곽 갱신
    useEffect(() => {
        const ctx = getOverlayCtx?.();
        const size = getCanvasCssSize?.() || { w: 0, h: 0 };
        clearOverlay(ctx, size.w, size.h);
        const sel = shapes.find((s) => s.id === selectedId);
        if (sel) drawSelectionOverlay(ctx, ensureBBox(sel));
    }, [selectedId, shapes, getOverlayCtx, getCanvasCssSize]); // :contentReference[oaicite:1]{index=1}

    useEffect(() => {
        const overlay = overlayRef.current;
        if (!overlay) return;

        const getLocalXY = (e) => {
            const r = overlay.getBoundingClientRect();
            return { x: e.clientX - r.left, y: e.clientY - r.top };
        };

        const paintOverlayPreview = (bb) => {
            const ctx = getOverlayCtx?.();
            const size = getCanvasCssSize?.() || { w: 0, h: 0 };
            clearOverlay(ctx, size.w, size.h);
            if (bb) drawSelectionOverlay(ctx, bb);
        };

        const onPointerDown = (e) => {
            if (e.button !== 0) return; // 좌클릭만
            e.preventDefault();
            e.stopPropagation();
            const { x, y } = getLocalXY(e);

            const hitCtx = hitRef.current?.getContext('2d');
            if (lastShapeCountRef.current !== (shapes?.length || 0)) {
                drawPickBuffer(hitCtx, shapes);
                lastShapeCountRef.current = shapes.length;
            }

            const key = pickAtSmart(hitCtx, x, y, 2);
            const id = key ? resolveKeyToId(shapes, key) : null;

            if (!id) {
                dispatch(setSelection(null));
                dragRef.current = { mode: 'idle' };
                paintOverlayPreview(null);
                return;
            }

            dispatch(setSelection(id));
            const fresh = store
                .getState()
                ?.shape?.list?.find((s) => s.id === id);
            const bb = ensureBBox(fresh || shapes.find((s) => s.id === id));
            const handle = hitHandle(bb, x, y);
            const mode = handle ? 'resize' : 'move';

            overlay.setPointerCapture?.(e.pointerId);
            dragRef.current = {
                mode,
                handle,
                x0: x,
                y0: y,
                lastX: x,
                lastY: y,
                startBB: bb,
                ids: [id],
                pid: e.pointerId,
            };
            overlay.style.cursor = handle
                ? cursorForHandle(handle)
                : 'grabbing';

            overlay.addEventListener('pointermove', onDragMove, {
                passive: false,
            });
            overlay.addEventListener('pointerup', onDragUp, { passive: false });

            paintOverlayPreview(bb);
        };

        const onDragMove = (e) => {
            const d = dragRef.current;
            if (!d || (d.pid != null && d.pid !== e.pointerId)) return;
            e.preventDefault();
            const { x, y } = getLocalXY(e);

            if (d.mode === 'move') {
                const dx = x - d.lastX,
                    dy = y - d.lastY;
                d.lastX = x;
                d.lastY = y;

                const bb = d.startBB;
                const preview = {
                    x: bb.x + (x - d.x0),
                    y: bb.y + (y - d.y0),
                    w: bb.w,
                    h: bb.h,
                };
                paintOverlayPreview(preview);

                // 2) 실제 상태 갱신
                if (dx || dy) dispatch(translateShapes({ ids: d.ids, dx, dy }));
            } else if (d.mode === 'resize') {
                const { x: bx, y: by, w: bw, h: bh } = d.startBB;
                let xMin = bx,
                    yMin = by,
                    xMax = bx + bw,
                    yMax = by + bh;
                if (d.handle.includes('w')) xMin = Math.min(x, xMax - 1);
                if (d.handle.includes('e')) xMax = Math.max(x, xMin + 1);
                if (d.handle.includes('n')) yMin = Math.min(y, yMax - 1);
                if (d.handle.includes('s')) yMax = Math.max(y, yMin + 1);

                // 1) 즉시 프리뷰
                paintOverlayPreview({
                    x: xMin,
                    y: yMin,
                    w: xMax - xMin,
                    h: yMax - yMin,
                });

                // 2) 실제 상태 갱신
                const ox = bx + bw / 2,
                    oy = by + bh / 2;
                const sx = (xMax - xMin) / Math.max(1, bw);
                const sy = (yMax - yMin) / Math.max(1, bh);
                dispatch(
                    scaleShapes({
                        ids: d.ids,
                        origin: { x: ox, y: oy },
                        sx,
                        sy,
                    })
                );
                d.lastX = x;
                d.lastY = y;
            }
        };

        const onDragUp = (e) => {
            const d = dragRef.current;
            overlay.releasePointerCapture?.(d?.pid);
            overlay.style.cursor = 'default';
            overlay.removeEventListener('pointermove', onDragMove, {
                passive: false,
            });
            overlay.removeEventListener('pointerup', onDragUp, {
                passive: false,
            });
            dragRef.current = { mode: 'idle' };
            e.preventDefault();

            // 업 직후 최종 상태로 프레임 다시 그림
            const state = store.getState();
            const selId = state?.selection?.id;
            const sel = state?.shape?.list?.find((s) => s.id === selId);
            paintOverlayPreview(sel ? ensureBBox(sel) : null);
        };

        const onDblClick = (e) => {
            e.preventDefault();
            const { x, y } = getLocalXY(e);
            const hitCtx = hitRef.current?.getContext('2d');
            const key = pickAtSmart(hitCtx, x, y, 2);
            const id = key ? resolveKeyToId(shapes, key) : null;
            if (id) dispatch(setSelection(id));
        };

        const onPointerMoveHover = (e) => {
            const { x, y } = getLocalXY(e);
            const state = store.getState();
            const sel = state?.shape?.list?.find(
                (s) => s.id === state?.selection?.id
            );
            if (!sel) {
                overlay.style.cursor = 'default';
                return;
            }
            const h = hitHandle(ensureBBox(sel), x, y);
            overlay.style.cursor = h ? cursorForHandle(h) : 'default';
        };

        overlay.addEventListener('pointerdown', onPointerDown, {
            passive: false,
        });
        overlay.addEventListener('pointermove', onPointerMoveHover, {
            passive: true,
        });

        return () => {
            overlay.removeEventListener('pointerdown', onPointerDown, {
                passive: false,
            });
            overlay.removeEventListener('pointermove', onPointerMoveHover, {
                passive: true,
            });
            overlay.removeEventListener('pointermove', onDragMove, {
                passive: false,
            });
            overlay.removeEventListener('pointerup', onDragUp, {
                passive: false,
            });
        };
    }, [
        overlayRef,
        stageRef,
        hitRef,
        shapes,
        selectedId,
        dispatch,
        getOverlayCtx,
        getCanvasCssSize,
        store,
    ]);
}
