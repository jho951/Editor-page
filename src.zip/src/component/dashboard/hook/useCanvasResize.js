import { useCallback, useRef, useState } from 'react';
import { CANVAS_RESIZE as CR } from '../constant/resize';
// 기존: '../util/canvas' 에 있던 drawResizePreview 의존 제거
import { setSize as setCanvasSize } from '../../../lib/redux/slice/canvasSlice';
import { clamp } from '../../../lib/redux/util/guide';

// 경량 프리뷰 드로잉
function drawResizePreview(ctx, w, h) {
    if (!ctx) return;
    const {
        DASH,
        LINE_WIDTH,
        COLOR,
        BADGE_BG,
        BADGE_FG,
        BADGE_PAD,
        BADGE_RADIUS,
        FONT,
    } = CR.PREVIEW;
    ctx.save();
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.setLineDash(DASH);
    ctx.lineWidth = LINE_WIDTH;
    ctx.strokeStyle = COLOR;
    ctx.strokeRect(0, 0, w, h);

    // 크기 배지
    const label = `${Math.round(w)} × ${Math.round(h)}`;
    ctx.font = FONT;
    const tw = ctx.measureText(label).width;
    const th = 16;
    const pad = BADGE_PAD;
    const bx = 8,
        by = 8,
        bw = tw + pad * 2,
        bh = th + pad * 2;

    // 라운드 사각형
    const r = BADGE_RADIUS;
    ctx.fillStyle = BADGE_BG;
    ctx.beginPath();
    ctx.moveTo(bx + r, by);
    ctx.arcTo(bx + bw, by, bx + bw, by + bh, r);
    ctx.arcTo(bx + bw, by + bh, bx, by + bh, r);
    ctx.arcTo(bx, by + bh, bx, by, r);
    ctx.arcTo(bx, by, bx + bw, by, r);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = BADGE_FG;
    ctx.fillText(label, bx + pad, by + pad + th - 4);
    ctx.restore();
}

export function useCanvasResize({ width, height, overlayCtxRef, dispatch }) {
    const [resizePreview, setResizePreview] = useState(null);
    const dragRef = useRef(null);

    const onPointerDown = useCallback(
        (e) => {
            // 커스텀 노브가 있을 때만 동작시키고 싶다면, 여기서 별도 히트 테스트를 넣으세요.
            e.currentTarget?.setPointerCapture?.(e.pointerId);
            dragRef.current = {
                mode: 'resize',
                pid: e.pointerId,
                startX: e.clientX,
                startY: e.clientY,
                baseW: width,
                baseH: height,
            };
            setResizePreview({ width, height });
            e.preventDefault();
        },
        [width, height]
    );

    const onPointerMove = useCallback(
        (e) => {
            const d = dragRef.current;
            if (!d || d.pid !== e.pointerId || d.mode !== 'resize') return;

            const dx = e.clientX - d.startX;
            const dy = e.clientY - d.startY;
            const w = clamp(d.baseW + dx, CR.MIN_W, CR.MAX_W ?? 1e9);
            const h = clamp(d.baseH + dy, CR.MIN_H, CR.MAX_H ?? 1e9);

            setResizePreview({ width: w, height: h });
            drawResizePreview(overlayCtxRef.current, w, h);
            e.preventDefault();
        },
        [overlayCtxRef]
    );

    const onPointerUp = useCallback(
        (e) => {
            const d = dragRef.current;
            if (!d || d.pid !== e.pointerId || d.mode !== 'resize') return;
            dragRef.current = null;

            const dx = e.clientX - d.startX;
            const dy = e.clientY - d.startY;
            const w = clamp(d.baseW + dx, CR.MIN_W, CR.MAX_W ?? 1e9);
            const h = clamp(d.baseH + dy, CR.MIN_H, CR.MAX_H ?? 1e9);

            setResizePreview(null);
            // 오버레이 정리
            const ctx = overlayCtxRef.current;
            if (ctx) ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
            dispatch(setCanvasSize({ width: w, height: h }));
        },
        [dispatch, overlayCtxRef]
    );

    return { resizePreview, onPointerDown, onPointerMove, onPointerUp };
}
