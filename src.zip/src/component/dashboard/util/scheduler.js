function createRafScheduler(fn) {
    let rafId = null;
    const schedule = () => {
        if (rafId) cancelAnimationFrame(rafId);
        rafId = requestAnimationFrame(() => {
            rafId = null;
            fn();
        });
    };
    const cancel = () => {
        if (rafId) cancelAnimationFrame(rafId);
        rafId = null;
    };
    return { schedule, cancel };
}
export { createRafScheduler };
