// overlay용 유틸: 점선 마퀴 + 리사이즈 핸들
export function clearOverlay(ctx, w, h) {
    if (!ctx) return;
    ctx.clearRect(0, 0, w, h);
}

export function drawMarquee(ctx, x, y, w, h) {
    if (!ctx) return;
    const nx = Math.min(x, x + w);
    const ny = Math.min(y, y + h);
    const nw = Math.abs(w);
    const nh = Math.abs(h);

    ctx.save();
    ctx.lineWidth = 1;
    ctx.setLineDash([6, 6]);
    ctx.strokeStyle = 'rgba(67, 56, 202, 0.8)'; // indigo-700
    ctx.strokeRect(nx, ny, nw, nh);

    // 핸들(8개)
    const s = 6;
    ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(67, 56, 202, 0.9)';
    const cx = nx + nw / 2;
    const cy = ny + nh / 2;
    const pts = [
        [nx, ny],
        [cx, ny],
        [nx + nw, ny],
        [nx, cy],
        [nx + nw, cy],
        [nx, ny + nh],
        [cx, ny + nh],
        [nx + nw, ny + nh],
    ];
    for (const [px, py] of pts) {
        ctx.fillRect(Math.round(px) - s / 2, Math.round(py) - s / 2, s, s);
    }
    ctx.restore();
}
