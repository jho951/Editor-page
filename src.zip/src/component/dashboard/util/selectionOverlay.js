// 선택 윤곽/핸들 드로잉 (overlay 전용)

// 이름 충돌 방지: clearOverlay → clearSelectionOverlay
export function clearSelectionOverlay(ctx, w, h) {
    if (!ctx) return;
    ctx.clearRect(0, 0, w, h);
}

export function drawSelectionFrame(ctx, bb) {
    if (!ctx || !bb) return;
    const { x, y, w, h } = bb;
    ctx.save();
    ctx.lineWidth = 1;
    ctx.setLineDash([6, 6]);
    ctx.strokeStyle = 'rgba(59,130,246,0.9)'; // blue-500
    ctx.strokeRect(x, y, w, h);
    ctx.restore();
}

export function drawHandles(ctx, bb) {
    if (!ctx || !bb) return;
    const { x, y, w, h } = bb;
    const s = 7;
    const half = s / 2;
    const pts = [
        [x, y],
        [x + w / 2, y],
        [x + w, y],
        [x, y + h / 2],
        [x + w, y + h / 2],
        [x, y + h],
        [x + w / 2, y + h],
        [x + w, y + h],
    ];
    ctx.save();
    ctx.setLineDash([]);
    ctx.fillStyle = '#2563eb';
    for (const [px, py] of pts) {
        ctx.fillRect(Math.round(px) - half, Math.round(py) - half, s, s);
    }
    ctx.restore();
}

export function drawSelectionOverlay(ctx, bb) {
    if (!ctx || !bb) return;
    drawSelectionFrame(ctx, bb);
    drawHandles(ctx, bb);
}
