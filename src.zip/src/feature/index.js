/**
 * @file index.js
 * @author YJH
 */

import { SHAPE_FEATURE } from './shape';

/**
 * @description 도형 모음
 */
const ShapeMap = {
    line: SHAPE_FEATURE.LineShape,
    circle: SHAPE_FEATURE.CircleShape,
    rect: SHAPE_FEATURE.RectShape,
};

export { ShapeMap };
