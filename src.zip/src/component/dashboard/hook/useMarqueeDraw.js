import { useEffect, useRef } from 'react';
import { useStore } from 'react-redux';
import { clearOverlay, drawMarquee } from '../util';
import { setSelection } from '../../../lib/redux/slice/selectionSlice';
import {
    addRectFromDrag,
    addEllipseFromDrag,
    addLineFromDrag,
    addPolygon,
    addStarFromDrag,
} from '../../../lib/redux/slice/shapeSlice';

const DRAW_TOOLS = ['rect', 'ellipse', 'line', 'polygon', 'star'];
const isDrawTool = (t) => DRAW_TOOLS.includes(t);

function makeRegularPolygonPoints(x0, y0, x1, y1, sides = 5) {
    const cx = (x0 + x1) / 2,
        cy = (y0 + y1) / 2;
    const rx = Math.abs(x1 - x0) / 2,
        ry = Math.abs(y1 - y0) / 2;
    const r = Math.min(rx, ry),
        N = Math.max(3, Math.floor(sides));
    const rot = -Math.PI / 2,
        pts = [];
    for (let i = 0; i < N; i++) {
        const a = rot + (i * 2 * Math.PI) / N;
        pts.push(cx + r * Math.cos(a), cy + r * Math.sin(a));
    }
    return pts;
}

export function useMarqueeDraw({
    overlayRef,
    stageRef,
    getOverlayCtx,
    getCanvasCssSize,
    getTool,
    getDraft,
    dispatch,
    autoSelect = true,
    constrainShift = true,
    autoReturnSelect = false,
    setToolAction = null,
}) {
    const dragRef = useRef(null);
    const rafRef = useRef(null);
    const store = useStore();

    useEffect(() => {
        const overlay = overlayRef.current;
        if (!overlay) return;

        const onPointerDown = (e) => {
            const tool = getTool?.();
            if (!isDrawTool(tool)) return;

            e.preventDefault();
            const rect = overlay.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            dragRef.current = { x0: x, y0: y, x1: x, y1: y };
            overlay.setPointerCapture?.(e.pointerId);

            window.addEventListener('pointermove', onPointerMove);
            window.addEventListener('pointerup', onPointerUp);

            drawFrame();
        };

        const onPointerMove = (e) => {
            const d = dragRef.current;
            if (!d) return;
            const rect = overlay.getBoundingClientRect();
            let nx = e.clientX - rect.left;
            let ny = e.clientY - rect.top;

            if (constrainShift && e.shiftKey) {
                const dx = nx - d.x0,
                    dy = ny - d.y0;
                const signX = Math.sign(dx || 1),
                    signY = Math.sign(dy || 1);
                const s = Math.max(Math.abs(dx), Math.abs(dy));
                nx = d.x0 + s * signX;
                ny = d.y0 + s * signY;
            }

            d.x1 = nx;
            d.y1 = ny;
            drawFrame();
        };

        const onPointerUp = () => {
            window.removeEventListener('pointermove', onPointerMove);
            window.removeEventListener('pointerup', onPointerUp);

            const d = dragRef.current;
            if (!d) return finishFrame(true);

            const { x0, y0, x1, y1 } = d;
            const dw = Math.abs(x1 - x0),
                dh = Math.abs(y1 - y0);
            if (dw < 1 && dh < 1) {
                dragRef.current = null;
                return finishFrame(true);
            }

            const tool = getTool?.();
            const draft = getDraft?.() || {};

            try {
                if (tool === 'rect')
                    dispatch(addRectFromDrag({ x0, y0, x1, y1, style: draft }));
                else if (tool === 'ellipse')
                    dispatch(
                        addEllipseFromDrag({ x0, y0, x1, y1, style: draft })
                    );
                else if (tool === 'line')
                    dispatch(
                        addLineFromDrag({
                            x1: x0,
                            y1: y0,
                            x2: x1,
                            y2: y1,
                            style: draft,
                        })
                    );
                else if (tool === 'polygon') {
                    const sides = Number(draft.polygonSides ?? 5);
                    const points = makeRegularPolygonPoints(
                        x0,
                        y0,
                        x1,
                        y1,
                        sides
                    );
                    dispatch(addPolygon({ points, style: draft }));
                } else if (tool === 'star') {
                    const spikes = Number(draft.spikes ?? 5);
                    const innerRatio = Number.isFinite(draft.innerRatio)
                        ? draft.innerRatio
                        : 0.5;
                    dispatch(
                        addStarFromDrag({
                            x0,
                            y0,
                            x1,
                            y1,
                            spikes,
                            innerRatio,
                            style: draft,
                        })
                    );
                }

                if (autoSelect) {
                    const list = store.getState()?.shape?.list || [];
                    const last = list[list.length - 1];
                    if (last?.id) dispatch(setSelection(last.id));
                }
                if (autoReturnSelect && setToolAction)
                    dispatch(setToolAction('select'));
            } finally {
                dragRef.current = null;
                finishFrame(true);
            }
        };

        const drawOverlay = (ctx, wPx, hPx) => {
            if (!ctx) return;
            clearOverlay?.(ctx, wPx, hPx);
            const d = dragRef.current;
            if (!d) return;
            drawMarquee?.(ctx, d.x0, d.y0, d.x1 - d.x0, d.y1 - d.y0);
        };

        const finishFrame = (clear) => {
            if (rafRef.current) cancelAnimationFrame(rafRef.current);
            rafRef.current = requestAnimationFrame(() => {
                const ctx = getOverlayCtx?.();
                const size = getCanvasCssSize?.() || { w: 0, h: 0 };
                if (clear) clearOverlay?.(ctx, size.w, size.h);
                else drawOverlay(ctx, size.w, size.h);
            });
        };
        const drawFrame = () => finishFrame(false);

        overlay.addEventListener('pointerdown', onPointerDown);
        return () => {
            overlay.removeEventListener('pointerdown', onPointerDown);
            window.removeEventListener('pointermove', onPointerMove);
            window.removeEventListener('pointerup', onPointerUp);
            if (rafRef.current) cancelAnimationFrame(rafRef.current);
        };
    }, [
        overlayRef,
        stageRef,
        dispatch,
        getTool,
        getDraft,
        getOverlayCtx,
        getCanvasCssSize,
        autoSelect,
        autoReturnSelect,
        setToolAction,
        constrainShift,
        store,
    ]);
}
