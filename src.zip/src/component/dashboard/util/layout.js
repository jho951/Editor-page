import { setupCanvas } from './setup';

function createLayout({
    stageRef,
    vectorRef,
    hitRef,
    overlayRef,
    onSizeChange,
    dpr,
}) {
    let lastW = 0,
        lastH = 0;

    const dprStrategy = (base) =>
        typeof dpr === 'function'
            ? dpr(base)
            : dpr || { vector: Math.min(base, 2.5), hitmap: 1, overlay: 1 };

    return function layout() {
        const stage = stageRef?.current;
        if (!stage) return;

        const rect = stage.getBoundingClientRect();
        const cssW = Math.max(1, Math.floor(rect.width));
        const cssH = Math.max(1, Math.floor(rect.height));

        const changed = lastW !== cssW || lastH !== cssH;
        if (changed) {
            lastW = cssW;
            lastH = cssH;
        }

        const base =
            (typeof window !== 'undefined' && window.devicePixelRatio) || 1;
        const DPR = dprStrategy(base);

        setupCanvas(vectorRef?.current, cssW, cssH, {
            dpr: DPR.vector,
            alpha: true,
        });
        // OPT: 히트맵은 알파 불필요 → false
        setupCanvas(hitRef?.current, cssW, cssH, {
            dpr: DPR.hitmap,
            alpha: false,
        });
        setupCanvas(overlayRef?.current, cssW, cssH, {
            dpr: DPR.overlay,
            alpha: true,
        });

        if (changed) onSizeChange?.({ width: cssW, height: cssH });
    };
}

export { createLayout };
